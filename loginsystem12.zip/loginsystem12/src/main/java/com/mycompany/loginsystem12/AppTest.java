/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loginsystem12;

/**
 *
 * @author dives
 */
    import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AppTest {
    @Test
    public void testCheckUserName() {
        Login login = new Login();
        assertTrue(login.checkUserName("user_"));
        assertFalse(login.checkUserName("username"));
    }

    @Test
    public void testCheckPasswordComplexity() {
        Login login = new Login();
        assertTrue(login.checkPasswordComplexity("Password1@"));
        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testRegisterUser() {
        Login login = new Login();
        assertEquals("User registered successfully.", login.registerUser("user_", "Password1@", "John", "Doe", "admin"));
        assertEquals("Error: Username already taken.", login.registerUser("user_", "Password1@", "John", "Doe", "admin"));
    }

    @Test
    public void testLoginUser() {
        Login login = new Login();
        login.registerUser("user_", "Password1@", "John", "Doe", "admin");
        assertTrue(login.loginUser("user_", "Password1@"));
        assertFalse(login.loginUser("user_", "wrongPassword"));
    }

    @Test
    public void testAddTask() {
        TaskManager taskManager = new TaskManager();
        assertEquals("Task successfully captured.", taskManager.addTask("Task1", "Description", "DevFirstName", "DevLastName", 5, "To Do", "High", "user_"));
        assertEquals("Error: Task description must be less than 50 characters.", taskManager.addTask("Task2", "This description is way too long and should fail.", "DevFirstName", "DevLastName", 5, "To Do", "High", "user_"));
    }

    @Test
    public void testUpdateTask() {
        TaskManager taskManager = new TaskManager();
        taskManager.addTask("Task1", "Description", "DevFirstName", "DevLastName", 5, "To Do", "High", "user_");
        assertEquals("Task successfully updated.", taskManager.updateTask(0, "Task1 Updated", "Description Updated", "DevFirstName", "DevLastName", 10, "Done", "High", "user_"));
        assertEquals("Error: Task not found.", taskManager.updateTask(999, "Task1 Updated", "Description Updated", "DevFirstName", "DevLastName", 10, "Done", "High", "user_"));
    }

    @Test
    public void testDeleteTask() {
        TaskManager taskManager = new TaskManager();
        taskManager.addTask("Task1", "Description", "DevFirstName", "DevLastName", 5, "To Do", "High", "user_");
        assertEquals("Task successfully deleted.", taskManager.deleteTask(0));
        assertEquals("Error: Task not found.", taskManager.deleteTask(999));
    }

    @Test
    public void testSearchTask() {
        TaskManager taskManager = new TaskManager();
        taskManager.addTask("Task1", "Description", "DevFirstName", "DevLastName", 5, "To Do", "High", "user_");
        assertNotNull(taskManager.searchTask("Task1"));
        assertNull(taskManager.searchTask("NonExistentTask"));
    }

    @Test
    public void testCreateTaskID() {
        Task task = new Task("Task1", "Description", "DevFirstName", "DevLastName", 5, "To Do", "High", "user_");
        assertEquals("TA:0:AME", task.getTaskID());
    }
}

