/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loginsystem12;

/**
 *
 * @author dives
 */

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
class Login {

    private List<User> users = new ArrayList<>();

    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        String pattern = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(password);
        return m.matches();
    }

    public String registerUser(String username, String password, String firstName, String lastName, String admin) {
        if (username == null || username.isEmpty()) {
            return "Error: Username cannot be empty.";
        }
        if (password == null || password.isEmpty()) {
            return "Error: Password cannot be empty.";
        }
        if (firstName == null || firstName.isEmpty()) {
            return "Error: First name cannot be empty.";
        }
        if (lastName == null || lastName.isEmpty()) {
            return "Error: Last name cannot be empty.";
        }
        if (!checkUserName(username)) {
            return "Error: Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Error: Password is not correctly formatted. Please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.";
        }
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return "Error: Username already taken.";
            }
        }
        String role = null;
        users.add(new User(username, password, firstName, lastName, role));
        return "User registered successfully.";
    }

    public boolean loginUser(String username, String password) {
        if (username == null || username.isEmpty()) {
            System.out.println("Error: Username cannot be empty.");
            return false;
        }
        if (password == null || password.isEmpty()) {
            System.out.println("Error: Password cannot be empty.");
            return false;
        }
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }

    public String returnLoginStatus(User user, boolean status) {
        if (status) {
            return "Welcome, " + user.getFirstName() + " " + user.getLastName() + ". Role: " + user.getRole();
        } else {
            return "Error: Login failed. Please check your username and password.";
        }
    }

    public List<User> getUsers() {
        return users;
    }
}





   


   


    

