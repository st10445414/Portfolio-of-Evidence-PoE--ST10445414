/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loginsystem12;

/**
 *
 * @author dives
 */
class Task {


    private static int taskCounter = 0;
    private String taskName;
    private String taskDescription;
    private String developerFirstName;
    private String developerLastName;
    private int taskDuration;
    private String taskStatus;
    private String taskID;
    private String priority;
    private String assignedTo;

    public Task(String taskName, String taskDescription, String developerFirstName, String developerLastName, int taskDuration, String taskStatus, String priority, String assignedTo) {
        this.taskName = taskName;
        this.taskDescription = taskDescription;
        this.developerFirstName = developerFirstName;
        this.developerLastName = developerLastName;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
        this.priority = priority;
        this.assignedTo = assignedTo;
        this.taskID = createTaskID();
        taskCounter++;
    }

    private String createTaskID() {
        return taskName.substring(0, 2).toUpperCase() + ":" + taskCounter + ":" + developerLastName.substring(developerLastName.length() - 3).toUpperCase();
    }

    public static boolean checkTaskDescription(String description) {
        return description.length() <= 50;
    }

    @Override
    public String toString() {
        return "Task Status: " + taskStatus + ", Developer: " + developerFirstName + " " + developerLastName + ", Task Number: " + taskCounter + ", Task Name: " + taskName + ", Task Description: " + taskDescription + ", Task ID: " + taskID + ", Duration: " + taskDuration + " hours, Priority: " + priority + ", Assigned to: " + assignedTo;
    }

    // Getter methods
    public String getTaskName() {
        return taskName;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    public String getDeveloperFirstName() {
        return developerFirstName;
    }

    public String getDeveloperLastName() {
        return developerLastName;
    }

    public int getTaskDuration() {
        return taskDuration;
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    public String getPriority() {
        return priority;
    }

    public String getAssignedTo() {
        return assignedTo;
    }

    public String getTaskID() {
        return taskID;
    }
}








   

    

