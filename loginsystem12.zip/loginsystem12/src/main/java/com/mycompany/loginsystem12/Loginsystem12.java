/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loginsystem12;

/**
 *
 * @author dives
 */




import java.util.Scanner;

public class Loginsystem12 {

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login loginSystem = new Login();
        TaskManager taskManager = new TaskManager();

        while (true) {
            System.out.println("\n=== Main Menu ===");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int option = getIntInput(scanner);

            switch (option) {
                case 1 -> registerUser(scanner, loginSystem);
                case 2 -> loginUser(scanner, loginSystem, taskManager);
                case 3 -> {
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                }
                default -> System.out.println("Invalid option. Please choose again.");
            }
        }
    }

    private static void registerUser(Scanner scanner, Login loginSystem) {
        System.out.println("\n--- Register User ---");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter role (admin/user): ");
        String role = scanner.nextLine();
        String result = loginSystem.registerUser(username, password, firstName, lastName, role);
        System.out.println(result);
    }

    private static void loginUser(Scanner scanner, Login loginSystem, TaskManager taskManager) {
        System.out.println("\n--- Login User ---");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        boolean loginStatus = loginSystem.loginUser(username, password);
        User user = null;
        for (User u : loginSystem.getUsers()) {
            if (u.getUsername().equals(username)) {
                user = u;
                break;
            }
        }
        if (user != null) {
            String loginMessage = loginSystem.returnLoginStatus(user, loginStatus);
            System.out.println(loginMessage);
            if (loginStatus) {
                handleTaskManagement(scanner, taskManager, user);
            }
        } else {
            System.out.println("Username or password incorrect, please try again.");
        }
    }

    private static void handleTaskManagement(Scanner scanner, TaskManager taskManager, User user) {
        while (true) {
            System.out.println("\n=== Task Management Menu ===");
            System.out.println("1. Add Task");
            System.out.println("2. Update Task");
            System.out.println("3. Delete Task");
            System.out.println("4. Search Task");
            System.out.println("5. Show Report");
            System.out.println("6. Logout");
            System.out.print("Choose an option: ");
            int taskOption = getIntInput(scanner);

            switch (taskOption) {
                case 1 -> addTask(scanner, taskManager);
                case 2 -> updateTask(scanner, taskManager);
                case 3 -> deleteTask(scanner, taskManager);
                case 4 -> searchTask(scanner, taskManager);
                case 5 -> taskManager.generateReports();
                case 6 -> {
                    System.out.println("Logging out...");
                    return;
                }
                default -> System.out.println("Invalid option. Please choose again.");
            }
        }
    }

    private static void addTask(Scanner scanner, TaskManager taskManager) {
        System.out.println("\n--- Add Task ---");
        System.out.print("Enter task name: ");
        String taskName = scanner.nextLine();
        System.out.print("Enter task description: ");
        String taskDescription = scanner.nextLine();
        if (!Task.checkTaskDescription(taskDescription)) {
            System.out.println("Error: Task description must be less than 50 characters.");
            return;
        }
        System.out.print("Enter developer first name: ");
        String developerFirstName = scanner.nextLine();
        System.out.print("Enter developer last name: ");
        String developerLastName = scanner.nextLine();
        System.out.print("Enter task duration in hours: ");
        int taskDuration = getIntInput(scanner);
        System.out.print("Enter task status (To Do / Doing / Done): ");
        String taskStatus = scanner.nextLine();
        System.out.print("Enter task priority (Low / Medium / High): ");
        String priority = scanner.nextLine();
        System.out.print("Enter username to assign the task to: ");
        String assignedTo = scanner.nextLine();
        String taskResult = taskManager.addTask(taskName, taskDescription, developerFirstName, developerLastName, taskDuration, taskStatus, priority, assignedTo);
        System.out.println(taskResult);
    }

    private static void updateTask(Scanner scanner, TaskManager taskManager) {
        System.out.println("\n--- Update Task ---");
        System.out.print("Enter task ID to update: ");
        int taskId = getIntInput(scanner);
        System.out.print("Enter new task name (leave blank to keep current): ");
        String taskName = scanner.nextLine();
        System.out.print("Enter new task description (leave blank to keep current): ");
        String taskDescription = scanner.nextLine();
        if (!taskDescription.isEmpty() && !Task.checkTaskDescription(taskDescription)) {
            System.out.println("Error: Task description must be less than 50 characters.");
            return;
        }
        System.out.print("Enter new developer first name (leave blank to keep current): ");
        String developerFirstName = scanner.nextLine();
        System.out.print("Enter new developer last name (leave blank to keep current): ");
        String developerLastName = scanner.nextLine();
        System.out.print("Enter new task duration in hours (leave blank to keep current): ");
        int taskDuration = 0;
        try {
            String durationInput = scanner.nextLine();
            if (!durationInput.isEmpty()) {
                taskDuration = Integer.parseInt(durationInput);
            }
        } catch (Exception e) {
            System.out.println("Invalid input. Please enter a number.");
            return;
        }
        System.out.print("Enter new task status (To Do / Doing / Done) (leave blank to keep current): ");
        String taskStatus = scanner.nextLine();
        System.out.print("Enter new task priority (Low / Medium / High) (leave blank to keep current): ");
        String priority = scanner.nextLine();
        System.out.print("Enter new username to assign the task to (leave blank to keep current): ");
        String assignedTo = scanner.nextLine();
        String taskResult = taskManager.updateTask(taskId, taskName.isEmpty() ? null : taskName, taskDescription.isEmpty() ? null : taskDescription, developerFirstName.isEmpty() ? null : developerFirstName, developerLastName.isEmpty() ? null : developerLastName, taskDuration, taskStatus.isEmpty() ? null : taskStatus, priority.isEmpty() ? null : priority, assignedTo.isEmpty() ? null : assignedTo);
        System.out.println(taskResult);
    }

    private static void deleteTask(Scanner scanner, TaskManager taskManager) {
        System.out.println("\n--- Delete Task ---");
        System.out.print("Enter task ID to delete: ");
        int taskId = getIntInput(scanner);
        String taskResult = taskManager.deleteTask(taskId);
        System.out.println(taskResult);
    }

    private static void searchTask(Scanner scanner, TaskManager taskManager) {
        System.out.println("\n--- Search Task ---");
        System.out.print("Enter task name to search: ");
        String taskName = scanner.nextLine();
        Task task = taskManager.searchTask(taskName);
        if (task != null) {
            System.out.println("Task found: " + task);
        } else {
            System.out.println("Task not found.");
        }
    }

    private static int getIntInput(Scanner scanner) {
        int input = 0;
        try {
            input = scanner.nextInt();
        } catch (Exception e) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next(); // clear the invalid input
        }
        scanner.nextLine(); // clear the buffer
        return input;
    }
}


}










    

    













