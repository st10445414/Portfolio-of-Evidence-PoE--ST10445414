/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loginsystem12;

/**
 *
 * @author dives
 */
import java.util.ArrayList;
import java.util.List;

class TaskManager {

    private List<Task> tasks = new ArrayList<>();
    private int totalHours = 0;

    public String addTask(String taskName, String taskDescription, String developerFirstName, String developerLastName, int taskDuration, String taskStatus, String priority, String assignedTo) {
        if (taskName == null || taskName.isEmpty()) {
            return "Error: Task name cannot be empty.";
        }
        if (taskDescription == null || taskDescription.isEmpty()) {
            return "Error: Task description cannot be empty.";
        }
        if (developerFirstName == null || developerFirstName.isEmpty()) {
            return "Error: Developer first name cannot be empty.";
        }
        if (developerLastName == null || developerLastName.isEmpty()) {
            return "Error: Developer last name cannot be empty.";
        }
        if (taskDuration <= 0) {
            return "Error: Task duration must be greater than zero.";
        }
        if (!Task.checkTaskDescription(taskDescription)) {
            return "Error: Task description must be less than 50 characters.";
        }
        Task task = new Task(taskName, taskDescription, developerFirstName, developerLastName, taskDuration, taskStatus, priority, assignedTo);
        tasks.add(task);
        totalHours += taskDuration;
        return "Task successfully captured.";
    }

    public String updateTask(int taskId, String taskName, String taskDescription, String developerFirstName, String developerLastName, int taskDuration, String taskStatus, String priority, String assignedTo) {
        Task task = getTaskById(taskId);
        if (task == null) {
            return "Error: Task not found.";
        }
        taskName = taskName != null ? taskName : task.getTaskName();
        taskDescription = taskDescription != null ? taskDescription : task.getTaskDescription();
        developerFirstName = developerFirstName != null ? developerFirstName : task.getDeveloperFirstName();
        developerLastName = developerLastName != null ? developerLastName : task.getDeveloperLastName();
        taskDuration = taskDuration != 0 ? taskDuration : task.getTaskDuration();
        taskStatus = taskStatus != null ? taskStatus : task.getTaskStatus();
        priority = priority != null ? priority : task.getPriority();
        assignedTo = assignedTo != null ? assignedTo : task.getAssignedTo();

        tasks.remove(task);
        totalHours -= task.getTaskDuration();
        task = new Task(taskName, taskDescription, developerFirstName, developerLastName, taskDuration, taskStatus, priority, assignedTo);
        tasks.add(task);
        totalHours += taskDuration;
        return "Task successfully updated.";
    }

    public String deleteTask(int taskId) {
        Task task = getTaskById(taskId);
        if (task == null) {
            return "Error: Task not found.";
        }
        tasks.remove(task);
        totalHours -= task.getTaskDuration();
        return "Task successfully deleted.";
    }

    public Task searchTask(String taskName) {
        for (Task task : tasks) {
            if (task.getTaskName().equalsIgnoreCase(taskName)) {
                return task;
            }
        }
        return null;
    }

    public void generateReports() {
        if (tasks.isEmpty()) {
            System.out.println("No tasks available.");
            return;
        }
        System.out.println("Task Report:");
        for (Task task : tasks) {
            System.out.println(task);
        }
        System.out.println("Total Duration: " + totalHours + " hours");
    }

    private Task getTaskById(int taskId) {
        for (Task task : tasks) {
            if (task.getTaskID().equals(taskId)) {
                return task;
            }
        }
        return null;
    }
}









    




    

